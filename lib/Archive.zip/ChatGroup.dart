import 'dart:convert';
import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:militarymessenger/cards/group_friend_message_card.dart';
import 'package:militarymessenger/cards/group_my_message_card.dart';
import 'package:militarymessenger/models/ChatModel.dart';
import 'package:militarymessenger/models/ConversationModel.dart';
import 'package:militarymessenger/objectbox.g.dart';
import 'package:swipe_to/swipe_to.dart';
import 'main.dart' as mains;
import 'package:http/http.dart' as http;
import 'Home.dart' as homes;


class ChatGroup extends StatefulWidget {
  final ConversationModel? conversation;
  int? roomId;

  ChatGroup(this.conversation, this.roomId);

  @override
  State<ChatGroup> createState() => _ChatGroupState(conversation, roomId);
}

List<String> nameList = [];
List<BubbleColor> bubbleColor = [];

class _ChatGroupState extends State<ChatGroup> {
  String apiKey = homes.apiKeyCore;
  var groupReceiversList;
  List<String> newNameList = List.from(nameList);

  final ConversationModel? conversation;
  int? roomId;

  _ChatGroupState(this.conversation, this.roomId);
  int? idUser;
  String? idReceiversGroup;

  TextEditingController inputTextController = new TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    idUser = mains.objectbox.boxUser.get(1)?.userId;
    idReceiversGroup = conversation?.idReceiversGroup;

    getDataUser();
  }

  bool firstTime = true;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(63.0),
        child: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.of(context).maybePop(),
          ),
          elevation: 0,
          titleSpacing: 0,
          title: ListTile(
            contentPadding: EdgeInsets.all(0),
            leading: ClipOval(
                child: conversation!.photoProfile != '' && conversation!.photoProfile != null ? CircleAvatar(
                  backgroundImage:  Image.memory(base64.decode(conversation!.photoProfile!)).image,
                  backgroundColor: Color(0xffF2F1F6),
                  radius: 20,
                ):
                CircleAvatar(
                  radius: 20,
                  backgroundColor: Color(0xffdde1ea),
                  child:  Icon(
                    Icons.people_rounded,
                    color: Colors.grey,
                  ),
                )
            ),
            title: ConstrainedBox(
              constraints: BoxConstraints(
                  maxWidth: 220
              ),
              child: Text(
                conversation!.fullName!,
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
                style: TextStyle(color: Colors.white, fontSize: 15,),
              ),
            ),
            subtitle: Text(
              "You, Contact 1, Contact 2",
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Colors.white.withOpacity(.7),
                fontSize: 12,
              ),
            ),
          ),
          actions: <Widget>[
            Icon(Icons.videocam),
            SizedBox(
              width: 15,
            ),
            Icon(Icons.call),
            SizedBox(
              width: 15,
            ),
            Icon(Icons.more_vert),
            SizedBox(
              width: 5,
            ),
          ],
        ),
      ),
      body: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Expanded(
              child: Padding(
                padding: EdgeInsets.only(right: 10, left: 10),
                child: Column(
                  children: [
                    Expanded(
                      child: StreamBuilder<List<ChatModel>>(
                          stream: homes.listController.stream,
                          builder: (context, snapshot)
                          {
                            if(snapshot.data != null){

                              var query = mains.objectbox.boxChat.query( ( ChatModel_.idRoom.equals(conversation!.roomId!)) ).build();
                              List<ChatModel> chats = query.find().reversed.toList();

                              if(query.find().isNotEmpty){
                                ConversationModel objConversation = ConversationModel(
                                    id: conversation!.id,
                                    message: query.find().toList().length == 0 ? '' : query.find().last.text,
                                    idReceiversGroup: conversation!.idReceiversGroup,
                                    fullName: conversation!.fullName,
                                    image: '',
                                    photoProfile: conversation!.photoProfile,
                                    date: conversation!.date,
                                    roomId: conversation!.roomId,
                                    messageCout: 0);

                                mains.objectbox.boxConversation.put(objConversation);
                              }

                              for(var item in json.decode(conversation!.idReceiversGroup!)){
                                if(!bubbleColor.map((e) => e.idUser).contains(item)){
                                  bubbleColor.add(BubbleColor(idUser: item, Color: Colors.primaries[Random().nextInt(Colors.primaries.length)]));
                                }
                              }

                              return ListView.builder(
                                  scrollDirection: Axis.vertical,
                                  reverse: true,
                                  shrinkWrap: false,
                                  padding: const EdgeInsets.only(top: 2, bottom: 2),
                                  itemCount: chats.length!=0 ? chats.length : 0,
                                  itemBuilder: (context, index) =>
                                  chats[index].idSender == idUser ?
                                  SwipeTo(
                                    onLeftSwipe: () {
                                    },
                                    child: MyMessageCardGroup(
                                      chats[index].text,
                                      DateFormat.Hm().format( DateTime.parse(chats[index].date) ),
                                      chats[index].sendStatus,
                                      index+1==chats.length?true:chats[index].idSender==chats[index+1].idSender?false:true,
                                    ),
                                  ) :
                                  //     : chats[index].idSender == idReceiversGroup ?
                                  FriendMessageCardGroup(
                                    chats[index].idSender!,
                                    chats[index].nameSender.toString(),
                                    chats[index].text,
                                    // chats[index].text,
                                    DateFormat.Hm().format( DateTime.parse(chats[index].date) ),
                                    bubbleColor.where((element) => element.idUser == chats[index].idSender).map((e) => e.Color).toString(),
                                    index+1==chats.length?true:chats[index].idSender==chats[index+1].idSender?false:true,
                                  )
                              );
                            }else{
                              if (snapshot.hasError) {
                                print(snapshot.error.toString());
                                return const Text("Error");
                              }
                              return const CircularProgressIndicator();
                            }
                          }
                      ),
                    )
                    ,
                  ],
                ),
              ),
            ),
            Container(
              color: Theme.of(context).backgroundColor,
              padding: EdgeInsets.only(right: 10, left: 10, top: 7, bottom: 25),
              margin: EdgeInsets.only(top: 10),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      showCupertinoModalPopup(
                        context: context,
                        builder: (context) => CupertinoActionSheet(
                          actions: [
                            CupertinoActionSheetAction(
                              child: Row(
                                children: [
                                  SizedBox(width: 10,),
                                  Icon(
                                    Icons.camera_alt_outlined,
                                    color: Theme.of(context).inputDecorationTheme.labelStyle?.color,
                                  ),
                                  SizedBox(width: 10,),
                                  Text('Camera',
                                    style: TextStyle(
                                        color: Theme.of(context).inputDecorationTheme.labelStyle?.color
                                    ),),
                                ],
                              ),
                              onPressed: () async {
                                // await getCamera();
                                Navigator.pop(context);
                              },
                            ),
                            CupertinoActionSheetAction(
                              child: Row(
                                children: [
                                  SizedBox(width: 10,),
                                  Icon(
                                    Icons.photo_album_outlined,
                                    color: Theme.of(context).inputDecorationTheme.labelStyle?.color,
                                  ),
                                  SizedBox(width: 10,),
                                  Text('Photo Album',
                                    style: TextStyle(
                                        color: Theme.of(context).inputDecorationTheme.labelStyle?.color
                                    ),),
                                ],
                              ),
                              onPressed: () async {
                                // await getCamera();
                                Navigator.pop(context);
                              },
                            ),
                            CupertinoActionSheetAction(
                              child: Row(
                                children: [
                                  SizedBox(width: 10,),
                                  Icon(
                                    Icons.insert_drive_file_outlined,
                                    color: Theme.of(context).inputDecorationTheme.labelStyle?.color,
                                  ),
                                  SizedBox(width: 10,),
                                  Text('Document',
                                    style: TextStyle(
                                        color: Theme.of(context).inputDecorationTheme.labelStyle?.color
                                    ),),
                                ],
                              ),
                              onPressed: () async {
                                // await getCamera();
                                Navigator.pop(context);
                              },
                            ),
                            CupertinoActionSheetAction(
                              child: Text('Cancel',
                                style: TextStyle(
                                  color: Color(0xFF2481CF),
                                ),),
                              onPressed: () {
                                Navigator.pop(context);
                              },
                            )
                          ],
                        ),
                      );
                    },
                    icon: Icon(
                      Icons.add,
                      size: 25,
                      color: Theme.of(context).floatingActionButtonTheme.backgroundColor,
                    ),
                  ),
                  Flexible(
                    child: Container(
                      margin: EdgeInsets.only(top: 10, bottom: 5),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      constraints: BoxConstraints(
                        minHeight: 25.0,
                        maxHeight: 100,
                        minWidth: MediaQuery.of(context).size.width,
                        maxWidth: MediaQuery.of(context).size.width,
                      ),
                      child: Scrollbar(
                        child: Expanded(
                          child: TextField(
                            cursorColor: Color(0xFF2481CF),
                            keyboardType: TextInputType.multiline,
                            controller: inputTextController,
                            maxLines: null,
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 12
                            ),
                            decoration: InputDecoration(
                                contentPadding: EdgeInsets.all(13),
                                border: InputBorder.none,
                                hintText: 'Type a message',
                                hintStyle: TextStyle(
                                  color: Color(0xff99999B),
                                )
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                      margin: EdgeInsets.only(left: 8),
                      child: IconButton(
                        icon: Icon(Icons.send),
                        onPressed: () async {
                          if(inputTextController.text.trim().isEmpty) {
                          }else{
                            final chat = ChatModel (
                              idSender: idUser,
                              idRoom: roomId,
                              idReceiversGroup: idReceiversGroup,
                              text: inputTextController.text,
                              date: DateTime.now().toString(),
                              sendStatus: '',
                              delivered: 0,
                              read: 0,
                            );

                            int id = mains.objectbox.boxChat.put(chat);

                            var msg = {};
                            msg["api_key"] = apiKey;
                            msg["decrypt_key"] = "";
                            msg["id_chat_model"] = id;
                            msg["type"] = "group";
                            msg["id_sender"] = idUser;
                            msg["id_receivers"] = idReceiversGroup;
                            msg["msg_data"] = chat.text;
                            msg["room_id"] = roomId;
                            msg["group_name"] = conversation?.fullName;

                            String msgString = json.encode(msg);

                            homes.channel.sink.add(msgString);

                            inputTextController.clear();

                          }
                        },
                        color: Theme.of(context).floatingActionButtonTheme.backgroundColor,
                      )
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<http.Response> getDataUser() async {

    String url ='https://chat.dev.r17.co.id/get_user.php';

    Map<String, dynamic> data = {
      'api_key': this.apiKey,
      'id_receivers': idReceiversGroup,
    };

    //encode Map to JSON
    //var body = "?api_key="+this.apiKey;

    var response = await http.post(Uri.parse(url),
      headers: {"Content-Type": "application/json"},
      body:jsonEncode(data),
    );
    if(response.statusCode == 200){
      //print("${response.body}");
      Map<String, dynamic> userMap = jsonDecode(response.body);

      if(userMap['code_status'] == 0){

        for(int i = 0; i < userMap['data'].length; i++){
          groupReceiversList = Map<String, dynamic>.from(userMap['data'][i]);

          nameList.insert(i, groupReceiversList['name']);
        }

      }else{
        print("ada yang salah!");
      }
    }
    else{
      print(response.statusCode);
      print("Gagal terhubung ke server!");
    }
    return response;
  }

}

class BubbleColor{
  int? idUser;
  MaterialColor? Color;

  BubbleColor({this.idUser, this.Color});
}

class TriangleClipper2 extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.lineTo(size.width, 0.0);
    path.lineTo(size.width / 2, size.height);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(TriangleClipper2 oldClipper) => false;
}

class TriangleClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.lineTo(size.width, 0.0);
    path.lineTo(size.width / 2, size.height);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(TriangleClipper oldClipper) => false;
}
