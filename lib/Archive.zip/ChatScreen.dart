import 'dart:convert';
import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:militarymessenger/contact.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:militarymessenger/models/ConversationModel.dart';
import 'package:militarymessenger/models/ChatModel.dart';
import 'package:militarymessenger/cards/friend_message_card_personal.dart';
import 'package:militarymessenger/cards/my_message_card_personal.dart';
import 'package:swipe_to/swipe_to.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_native_contact_picker/flutter_native_contact_picker.dart';
import 'package:open_file/open_file.dart';
import 'package:uuid/uuid.dart';

import 'package:web_socket_channel/io.dart';
import 'objectbox.g.dart';
//import 'DBHelpers.dart';
import 'dart:async';
import 'package:rxdart/rxdart.dart';
import 'package:intl/intl.dart';
import 'main.dart' as mains;
import 'Home.dart' as homes;
import 'package:http/http.dart' as http;

int lastConnection = 0;

class ChatScreen extends StatefulWidget {
  final ConversationModel? conversation;
  Store? store;
  int roomId;

  ChatScreen(this.conversation, this.roomId);


  @override
  _ChatScreenState createState() => _ChatScreenState(conversation,roomId);
}

class _ChatScreenState extends State<ChatScreen> {
  final ConversationModel? conversation;
  int? roomId;
  Store? store;

  _ChatScreenState(this.conversation, this.roomId);
  int? idUser;
  int? idReceiver;

  TextEditingController inputTextController = new TextEditingController();

  String apiKey = homes.apiKeyCore;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    idUser = mains.objectbox.boxUser.get(1)?.userId;
    idReceiver = conversation?.idReceiver;


    //update chat read when open chat
    var query = mains.objectbox.boxChat.query(ChatModel_.read.equals(0) & (ChatModel_.idReceiver.equals(idUser!) & (ChatModel_.idSender.equals(idReceiver!)))).build();
    List<ChatModel> chats = query.find().toList();
    for(int i=0;i<chats.length;i++){
      var msg = {};
      msg["api_key"] = apiKey;
      msg["type"] = "status_deliver";
      msg["id_chat_model_friends"] = chats[i].idChatFriends;
      msg["id_sender"] = chats[i].idSender;
      msg["id_receiver"] = chats[i].idReceiver;
      msg["room_id"] = conversation!.roomId;
      String msgString = json.encode(msg);
      // print(msgString);
      homes.channel.sink.add(msgString);

      //update status to read=1 deliver=1
      final chat = ChatModel(
        id: chats[i].id,
        idSender: chats[i].idSender,
        idReceiver: chats[i].idReceiver,
        text: chats[i].text,
        date: chats[i].date,
        sendStatus: chats[i].sendStatus,
        delivered: chats[i].delivered,
        read: 1,
      );
      int id = mains.objectbox.boxChat.put(chat);
    }

    //update conversation on open chat
    final objConversation = ConversationModel(
      id: conversation!.id,
      message: conversation!.message,
      date: conversation!.date,
      idReceiver: conversation!.idReceiver,
      fullName: conversation!.fullName,
      image: conversation!.image,
      photoProfile: conversation!.photoProfile,
      messageCout: 0,
      statusReceiver: conversation!.statusReceiver,
      roomId: conversation!.roomId,
      // replyMessage: conversation!.replyMessage,
    );
    mains.objectbox.boxConversation.put(objConversation);

  }

  bool _isWriting = false;
  bool firstTime = true;

  final _focusNode = FocusNode();

  @override
  File? image;
  Contact? contact;

  Future getImage() async {
    // final ImagePicker _picker = ImagePicker();
    // await _picker.pickImage(source: ImageSource.gallery, imageQuality: 50).then((xFile) {
    //   if (xFile != null) {
    //     image = File(xFile.path);
    //     uploadImage();
    //   }
    // });
    final ImagePicker _picker = ImagePicker();
    final XFile? imagePicked = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 50);
    if (imagePicked != null) {
      setState(() {
        image = File(imagePicked.path);
      });
    }
  }

  Future uploadImage() async {
    String fileName = Uuid().v1();
    var ref = FirebaseStorage.instance.ref().child('images').child("$fileName.jpg");
    var uploadTask = ref.putFile(image!);
    // String imageUrl = await uploadTask.ref.getDownloadURL();
    // print(imageUrl);
  }

  Future getCamera() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? imageCamera = await _picker.pickImage(source: ImageSource.camera);
    setState(() {
      image = imageCamera as File?;
    });
  }

  Future getContact() async {
    final FlutterContactPicker _contactPicker = new FlutterContactPicker();
    Contact? contacts = await _contactPicker.selectContact();
    setState(() {
      contact = contacts;
    });
  }


  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {

    DateTime dateTime = DateTime.parse(conversation!.date!);
    String formattedDate = DateFormat('HH:mm').format(dateTime);

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(63.0),
          child: AppBar(
            elevation: 0,
            leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.of(context).maybePop(),
            ),
            titleSpacing: 0,
            title: ListTile(
                contentPadding: EdgeInsets.all(0),
                leading:
                ClipOval(
                  child: conversation!.photoProfile != null  ?  conversation!.photoProfile != '' ? CircleAvatar(
                    backgroundImage:  Image.memory(base64.decode(conversation!.photoProfile!)).image,
                    backgroundColor: Color(0xffF2F1F6),
                    radius: 20,
                  ):
                  CircleAvatar(
                    radius: 20,
                    backgroundColor: Color(0xffdde1ea),
                    child:  Icon(
                      Icons.person,
                      color: Colors.grey,
                    ),
                  ) : CircleAvatar(
                    radius: 20,
                    backgroundColor: Color(0xffdde1ea),
                    child:  Icon(
                      Icons.person,
                      color: Colors.grey,
                    ),
                  )
                ),
                title: ConstrainedBox(
                  constraints: BoxConstraints(
                      maxWidth: 220
                  ),
                  child: Text(
                    conversation!.fullName!,
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                    style: TextStyle(color: Colors.white, fontSize: 15,),
                  ),
                ),
                subtitle:Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      Expanded(
                          child: StreamBuilder<List<ConversationModel>>(
                              stream: homes.listControllerConversation.stream,
                              builder: (context, snapshot)
                              {

                                var queryConv = mains.objectbox.boxConversation.query(ConversationModel_.id.equals(conversation!.id)).build();
                                //List<ConversationModel> queryConv = queryConv.find().reversed.toList();
                                if(queryConv.find().first.statusReceiver==''){
                                  return Text(
                                    formattedDate,
                                    style: TextStyle(color: Colors.white.withOpacity(.7)),
                                  );
                                }
                                else{
                                  return Text(
                                    queryConv.find().first.statusReceiver,
                                    style: TextStyle(color: Color(0xFF25D366)),
                                  );
                                }

                                //return const CircularProgressIndicator();
                              }
                          )),
                    ]
                )
            ),
            actions: <Widget>[
              Icon(Icons.videocam),
              SizedBox(
                width: 15,
              ),
              Icon(Icons.call),
              SizedBox(
                width: 15,
              ),
            ],
          ),
        ),
        body: Container(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Padding(
                  padding: EdgeInsets.only(right: 10, left: 10),
                  child: StreamBuilder<List<ChatModel>>(
                    stream: homes.listController.stream,
                    builder: (context, snapshot)
                    {
                      if (snapshot.data != null) {
                        //update chat read status when receive new chat and chatscreen standby
                        var query2 = mains.objectbox.boxChat.query(ChatModel_.read.equals(0) & (ChatModel_.idReceiver.equals(idUser!) & (ChatModel_.idSender.equals(idReceiver!)))).build();
                        List<ChatModel> chats2 = query2.find().toList();
                        for(int i=0;i<chats2.length;i++){
                          var msg = {};
                          msg["api_key"] = apiKey;
                          msg["type"] = "status_deliver";
                          msg["id_chat_model_friends"] = chats2[i].idChatFriends;
                          msg["id_sender"] = chats2[i].idSender;
                          msg["id_receiver"] = chats2[i].idReceiver;
                          msg["room_id"] = conversation!.roomId;
                          String msgString = json.encode(msg);
                          homes.channel.sink.add(msgString);

                          //update status to read=1 deliver=1
                          final chat = ChatModel(
                            id: chats2[i].id,
                            idSender: chats2[i].idSender,
                            idReceiver: chats2[i].idReceiver,
                            text: chats2[i].text,
                            date: chats2[i].date,
                            sendStatus: chats2[i].sendStatus,
                            delivered: chats2[i].delivered,
                            read: 1,
                          );
                          int id = mains.objectbox.boxChat.put(chat);
                        }

                        var query = mains.objectbox.boxChat.query( (ChatModel_.idReceiver.equals(idReceiver!) & ChatModel_.idSender.equals(idUser!)) | ChatModel_.idReceiver.equals(idUser!) & ChatModel_.idSender.equals(idReceiver!)).build();
                        List<ChatModel> chats = query.find().reversed.toList();

                        if(query.find().isNotEmpty & firstTime==false) {
                          //update conversation count=0 when receive new chat and user create new chat (both when chatscreen standby)
                          final objConversation = ConversationModel(
                            id: conversation!.id,
                            message: query.find().toList().length == 0 ? '' : query.find().last.text,
                            date: DateTime.now().toString(),
                            idReceiver: conversation!.idReceiver,
                            fullName: conversation!.fullName,
                            image: conversation!.image,
                            photoProfile: conversation!.photoProfile,
                            messageCout: 0,
                            statusReceiver: conversation!.statusReceiver,
                            roomId: conversation!.roomId,
                            // replyMessage: conversation!.replyMessage,
                          );
                          mains.objectbox.boxConversation.put(objConversation);
                        }
                        firstTime = false;

                        return ListView.builder(
                            scrollDirection: Axis.vertical,
                            reverse: true,
                            shrinkWrap: false,
                            padding: const EdgeInsets.all(2),
                            itemCount: chats.length!=0 ? chats.length : 0,
                            itemBuilder: (context, index) =>
                            chats[index].idSender == idUser ?
                            SwipeTo(
                              onLeftSwipe: () {
                              },
                              child: MyMessageCardPersonal(
                                chats[index].text,
                                DateFormat.Hm().format( DateTime.parse(chats[index].date) ),
                                chats[index].sendStatus,
                                index+1==chats.length?true:chats[index].idSender==chats[index+1].idSender?false:true,
                              ),
                            )
                                : chats[index].idSender == idReceiver ?
                            FriendMessageCardPersonal(
                              chats[index].text,
                              // chats[index].text,
                              DateFormat.Hm().format( DateTime.parse(chats[index].date) ),
                              index+1==chats.length?true:chats[index].idSender==chats[index+1].idSender?false:true,
                            ) : Container()
                        );
                      }else{
                        if (snapshot.hasError) {
                          print(snapshot.error.toString());
                          return const Text("Error");
                        }
                        return const CircularProgressIndicator();
                      }},
                  ),
                ),
              ),
              SizedBox(height: 10,),
              Container(
                color: Theme.of(context).backgroundColor,
                padding: EdgeInsets.only(right: 10, left: 10, top: 7, bottom: 25),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () {
                        showCupertinoModalPopup(
                            context: context,
                            builder: (context) => CupertinoActionSheet(
                              actions: <Widget>[
                                Container(
                                  color: Colors.white,
                                  child: CupertinoActionSheetAction(
                                    onPressed: () {
                                      pickMedia();
                                      Navigator.pop(context);
                                    },
                                    child: const Text(
                                      'Photo & Video Library',
                                      style: TextStyle(
                                          color: Color(0xFF2481CF)
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  color: Colors.white,
                                  child: CupertinoActionSheetAction(
                                    child: const Text(
                                      'Documents',
                                      style: TextStyle(
                                          color: Color(0xFF2481CF)
                                      ),
                                    ),
                                    onPressed: () {
                                      pickFile();
                                    },
                                  ),
                                ),
                                Container(
                                  color: Colors.white,
                                  child: CupertinoActionSheetAction(
                                    child: const Text(
                                      'Contacts',
                                      style: TextStyle(
                                          color: Color(0xFF2481CF)
                                      ),
                                    ),
                                    onPressed: () {
                                      getContact();
                                    },
                                  ),
                                ),
                              ],
                              cancelButton: Container(
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(10)
                                ),
                                child: CupertinoActionSheetAction(
                                  child: const Text(
                                    'Cancel',
                                    style: TextStyle(
                                        color: Color(0xFF2481CF)
                                    ),
                                  ),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ),
                            )
                        );
                      },
                      icon: Icon(
                        Icons.add,
                        size: 25,
                        color: Theme.of(context).floatingActionButtonTheme.backgroundColor,
                      ),
                    ),
                    Flexible(
                      child: Column(
                        children: [
                          SizedBox(height: 5,),
                          Container(
                            margin: EdgeInsets.only(bottom: 5),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(5),
                            ),
                            constraints: BoxConstraints(
                              minHeight: 25.0,
                              maxHeight: 100,
                              minWidth: MediaQuery.of(context).size.width,
                              maxWidth: MediaQuery.of(context).size.width,
                            ),
                            child: Scrollbar(
                              child: Expanded(
                                child: TextField(
                                  cursorColor: Colors.grey,
                                  keyboardType: TextInputType.multiline,
                                  controller: inputTextController,
                                  focusNode: _focusNode,
                                  onChanged: (text) {
                                    if (!_isWriting){
                                      _isWriting = true;

                                      //update typing status when type messages
                                      var msg = {};
                                      msg["api_key"] = apiKey;
                                      msg["type"] = "status_typing";
                                      msg["id_sender"] = idUser;
                                      msg["id_receiver"] = idReceiver;
                                      msg["room_id"] = conversation!.roomId;
                                      String msgString = json.encode(msg);
                                      homes.channel.sink.add(msgString);

                                      setState((){});
                                      Future.delayed(Duration(milliseconds: 2000)).whenComplete((){
                                        _isWriting = false;
                                        setState((){});
                                      });
                                    }
                                  },
                                  maxLines: null,
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 12
                                  ),
                                  decoration: InputDecoration(
                                      contentPadding: EdgeInsets.all(13),
                                      border: InputBorder.none,
                                      hintText: 'Type a message',
                                      hintStyle: TextStyle(
                                          color: Color(0xff99999B),
                                          fontSize: 12
                                      )
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                        margin: EdgeInsets.only(left: 8),
                        child: IconButton(
                          icon: Icon(Icons.send),
                          onPressed: () async {
                            if(inputTextController.text.trim().isEmpty) {

                            }
                            else {
                              final chat = ChatModel (
                                idSender: idUser,
                                idReceiver: idReceiver,
                                text: inputTextController.text,
                                date: DateTime.now().toString(),
                                sendStatus: '',
                                delivered: 0,
                                read: 0,
                              );

                              int id = mains.objectbox.boxChat.put(chat);

                              var msg = {};
                              msg["api_key"] = apiKey;
                              msg["decrypt_key"] = "";
                              msg["id_chat_model"] = id;
                              msg["type"] = "pm";
                              msg["id_sender"] = idUser;
                              msg["id_receiver"] = idReceiver;
                              msg["msg_data"] = chat.text;
                              msg["room_id"] = roomId;

                              String msgString = json.encode(msg);

                              homes.channel.sink.add(msgString);

                              ChatModel? chats = mains.objectbox.boxChat.get(id);

                              inputTextController.clear();
                            }
                          },
                          color: Theme.of(context).floatingActionButtonTheme.backgroundColor,
                        )
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void pickMedia() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.image,
    );
    if(result == null) return;

    PlatformFile? file = result.files.first;

    viewFile(file);
  }

  void pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['doc', 'pdf'],
    );
    if(result == null) return;

    // PlatformFile? file = result!.files.first;

  }

  void viewFile(PlatformFile file) {
    OpenFile.open(file.path);
  }

// void replyToMessage(ChatModel message) {
//   setState(() {
//     replyMessage = message;
//   });
// }

}