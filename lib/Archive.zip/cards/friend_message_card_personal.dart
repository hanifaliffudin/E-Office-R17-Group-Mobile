import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class FriendMessageCardPersonal extends StatelessWidget {
  final String message;
  final String date;
  final bool showTriangle;

  const FriendMessageCardPersonal(
      this.message,
      this.date,
      this.showTriangle,
      );

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Stack(
            overflow: Overflow.visible,
            children: <Widget>[
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12,vertical: 12,),
                margin: EdgeInsets.symmetric(horizontal: 10,vertical: 2),
                decoration: BoxDecoration(
                  color: Color(0xFFEEEEEE),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.70),
                      child:
                      Text(
                        message,
                        style: TextStyle(fontSize: 16, color: Colors.black),
                        textAlign: TextAlign.left,
                      ),
                    ),
                    SizedBox(width: 5,),
                  ],
                ),
              ),
              // Container(
              //   child:
              //   Row(
              //     mainAxisAlignment: MainAxisAlignment.start,
              //     children: [
              //       Padding(
              //         padding: const EdgeInsets.only(top: 3,left:34),
              //         child:Align(
              //           alignment: Alignment.centerLeft,
              //           child: Text(
              //             date,
              //             style: TextStyle(fontSize: 10, color: Colors.grey),
              //           ),
              //         ),
              //       ),
              //     ],
              //   ),
              // ),
              Positioned(
                left:0,
                top: 2,
                child: ClipPath(
                  clipper: TriangleClipper(),
                  child: Container(
                    height: 20,
                    width: 30,
                    color: showTriangle?Color(0xFFEEEEEE):Colors.transparent,
                  ),
                ),
              )
            ],
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text(date,
                style: TextStyle(
                  fontSize: 11,
                ),),
            ],
          )
        ],
      ),
    );
  }
}

class TriangleClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.lineTo(size.width, 0.0);
    path.lineTo(size.width / 2, size.height);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(TriangleClipper oldClipper) => false;
}