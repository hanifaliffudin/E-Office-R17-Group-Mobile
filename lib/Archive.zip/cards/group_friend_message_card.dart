import 'dart:convert';
import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class FriendMessageCardGroup extends StatelessWidget {
  final int idSender;
  final String name;
  final String message;
  final String date;
  final String color;
  final bool showTriangle;

  const FriendMessageCardGroup(
      this.idSender,
      this.name,
      this.message,
      this.date,
      this.color,
      this.showTriangle,
      );

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Stack(
            overflow: Overflow.visible,
            children: <Widget>[
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12,vertical: 12,),
                margin: EdgeInsets.symmetric(horizontal: 10,vertical: 2),
                decoration: BoxDecoration(
                  color: Color(0xFFEEEEEE),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.70),
                      child:
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(name,
                            style: TextStyle(
                                color: Color(int.parse(color.substring(40, color.length-3), radix: 16) + 0xFF000000),
                                fontWeight: FontWeight.bold
                            ),),
                          SizedBox(height: 5,),
                          Text(
                            message,
                            style: TextStyle(fontSize: 16, color: Colors.black),
                            textAlign: TextAlign.left,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 5,),
                  ],
                ),
              ),
              Positioned(
                left:0,
                top: 2,
                child: ClipPath(
                  clipper: TriangleClipper(),
                  child: Container(
                    height: 20,
                    width: 30,
                    color: showTriangle?Color(0xFFEEEEEE):Colors.transparent,
                  ),
                ),
              )
            ],
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text(date,
                style: TextStyle(
                  fontSize: 11,
                ),),
            ],
          )
        ],
      ),
    );
  }
}


class TriangleClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.lineTo(size.width, 0.0);
    path.lineTo(size.width / 2, size.height);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(TriangleClipper oldClipper) => false;
}