import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:io' as Io;
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:militarymessenger/ChatScreen.dart';
import 'package:militarymessenger/ChatTabScreen.dart';
import 'package:militarymessenger/FeedTabScreen.dart';
import 'package:militarymessenger/XploreTabScreen.dart';
import 'package:militarymessenger/CallTabScreen.dart';
import 'package:militarymessenger/NewGroupPage.dart';
import 'package:militarymessenger/SettingsPage.dart';
import 'package:militarymessenger/AboutPage.dart';
import 'package:militarymessenger/contact.dart';
import 'package:militarymessenger/profile.dart';
import 'package:militarymessenger/settings/chat.dart';
import 'package:militarymessenger/chat.dart';
import 'package:militarymessenger/settings/notification.dart';
import 'package:path_provider/path_provider.dart';
import 'package:rxdart/rxdart.dart';
import 'models/ContactModel.dart';
import 'models/UserModel.dart';
import 'objectbox.g.dart';
import 'package:militarymessenger/models/ChatModel.dart';
import 'package:militarymessenger/models/ConversationModel.dart';
import 'package:militarymessenger/models/ContactModel.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'dart:io';
import 'package:web_socket_channel/io.dart';
import 'main.dart' as mains;
import 'ObjectBox.dart' as obox;
import 'package:http/http.dart' as http;


StreamController<List<ChatModel>> listController = new BehaviorSubject();
StreamController<List<ConversationModel>> listControllerConversation = new BehaviorSubject();
StreamController<List<ContactModel>> listControllerContact = new BehaviorSubject();
StreamController<List<UserModel>> listControllerUser = new BehaviorSubject();

String apiKeyCore = '1Hw3G9UYOhounou0679y3*OhouH978%hOtfr57fRtug#9UI8nl7iU4Yt5vR6Fb87tLRB5u3g4Hi92983huiU3g5bkH5BVGv3daf2F5e2Ae4k6F5vblUwIJD9W7ryiuBL24Lbv3P';

var channel;
int? idSender;

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> with TickerProviderStateMixin{
  TabController? _tabController;
  Store? _store;
  String apiKey = apiKeyCore;
  final String? email = mains.objectbox.boxUser.get(1)?.email;
  String? name;
  String? phone;
  String? photo;
  Uint8List? bytes;

  Future<void> setupInteractedMessage() async {
    // Get any messages which caused the application to open from
    // a terminated state.
    RemoteMessage? initialMessage =
    await FirebaseMessaging.instance.getInitialMessage();

    // If the message also contains a data property with a "type" of "chat",
    // navigate to a chat screen
    if (initialMessage != null) {
      _handleMessage(initialMessage);
    }

    // Also handle any interaction when the app is in the background via a
    // Stream listener
    FirebaseMessaging.onMessageOpenedApp.listen(_handleMessage);

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print('A new onMessageOpenedApp event was published!');

    });
  }

  void _handleMessage(RemoteMessage message) {
    print(message.data['type']);
    if (message.data['type'] == 'pm') {

      //  get id conversation from message data and then query find to object box conversation,
      var query = mains.objectbox.boxConversation.query(ConversationModel_.idReceiver.equals(int.parse(message.data['id_sender']))).build();
      if(query.find().isNotEmpty) {
        int? count = query
            .find()
            .first
            .messageCout;
        if (count == null)
          count = 1;
        else
          count = count + 1;

        ConversationModel objConversation2 = ConversationModel(
            id: query.find().first.id,
            idReceiver: int.parse(message.data['id_sender']),
            fullName: query.find().first.fullName,
            image: query.find().first.image,
            photoProfile: query.find().first.photoProfile,
            message: message.data['msg_data'],
            date: message.data['msg_date'],
            messageCout: count,
            statusReceiver: query.find().first.statusReceiver,
            roomId: int.parse(message.data['room_id'])
        );
        mains.objectbox.boxConversation.put(objConversation2);

        Navigator.of(context).push(
            MaterialPageRoute(builder: (BuildContext context)=>ChatScreen(objConversation2, int.parse(message.data['room_id']))
            ));

      }
      else{

        ConversationModel objConversation2 = ConversationModel(
            id: 0,
            idReceiver: int.parse(message.data['id_sender']),
            fullName: message.data['name_sender'],
            image: '',
            photoProfile: message.data['photo'],
            message: message.data['msg_data'],
            date: message.data['msg_date'],
            messageCout: 1,
            statusReceiver: '',
            roomId: int.parse(message.data['room_id']));
        mains.objectbox.boxConversation.put(objConversation2);

        Navigator.of(context).push(
            MaterialPageRoute(builder: (BuildContext context)=>ChatScreen(objConversation2, int.parse(message.data['room_id']))
            ));
      }

      var query2 = mains.objectbox.boxChat.query(ChatModel_.idChatFriends.equals(int.parse(message.data['id_chat_model']))).build();
      if(query2.find().isNotEmpty) {}
      else{
        //update Chat Model
        final chat = ChatModel(
          idChatFriends: int.parse(message.data['id_chat_model']),
          idSender: int.parse(message.data['id_sender']),
          idReceiver: int.parse(message.data['id_receiver']),
          text: message.data['msg_data'],
          date: message.data['msg_date'],
          sendStatus: '',
          delivered: 0,
          read: 0,
        );
        int id = mains.objectbox.boxChat.put(chat);
      }


    }
    else if(message.data['type'] == 'group'){

      //  get id conversation from message data and then query find to object box conversation,
      var query = mains.objectbox.boxConversation.query(ConversationModel_.roomId.equals(int.parse(message.data['room_id']))).build();
      if(query.find().isNotEmpty) {
        int? count = query
            .find()
            .first
            .messageCout;
        if (count == null)
          count = 1;
        else
          count = count + 1;

        print(query.find().first.photoProfile);
        ConversationModel objConversation3 = ConversationModel(
            id: query.find().first.id,
            idReceiversGroup: message.data['id_receivers'],
            fullName: query.find().first.fullName,
            image: query.find().first.image,
            photoProfile: query.find().first.photoProfile,
            message: message.data['msg_data'],
            date: message.data['msg_date'],
            messageCout: count,
            statusReceiver: query.find().first.statusReceiver,
            roomId: query.find().first.roomId
        );
        // mains.objectbox.boxConversation.put(objConversation3);

        // Navigator.of(context).push(
        //     MaterialPageRoute(builder: (BuildContext context)=>ChatScreen(objConversation3, int.parse(message.data['room_id']))
        //     ));

      }
      else{
        print(message.data['room_id']);
        ConversationModel objConversation3 = ConversationModel(
            id: 0,
            idReceiversGroup: message.data['id_receivers'],
            fullName: message.data['name_sender'],
            image: '',
            photoProfile: message.data['photo'],
            message: message.data['msg_data'],
            date: message.data['msg_date'],
            messageCout: 1,
            statusReceiver: '',
            roomId: int.parse(message.data['room_id']));
        // mains.objectbox.boxConversation.put(objConversation3);

        // Navigator.of(context).push(
        //     MaterialPageRoute(builder: (BuildContext context)=>ChatScreen(objConversation3, int.parse(message.data['room_id']))
        //     ));
      }

      // var query2 = mains.objectbox.boxChat.query(ChatModel_.idChatFriends.equals(int.parse(message.data['id_chat_model']))).build();
      // if(query2.find().isNotEmpty) {}
      // else{
      //   //update Chat Model
      //   final chat = ChatModel(
      //     idChatFriends: int.parse(message.data['id_chat_model']),
      //     idSender: int.parse(message.data['id_sender']),
      //     idReceiver: int.parse(message.data['id_receiver']),
      //     text: message.data['msg_data'],
      //     date: message.data['msg_date'],
      //     sendStatus: '',
      //     delivered: 0,
      //     read: 0,
      //   );
      //   int id = mains.objectbox.boxChat.put(chat);
      // }

    }
    else if(message.data['type']=="status_deliver"){
      ChatModel cm = mains.objectbox.boxChat.get(int.parse(message.data['id_chat_model']))!;
      print(message.data['send_status']);
      final chat = ChatModel(
        id: cm.id,
        idSender: cm.idSender,
        idReceiver: cm.idReceiver,
        text: cm.text,
        date: cm.date,
        sendStatus: message.data['send_status'],
        delivered: 0,
        read: 0,
      );
      int id = mains.objectbox.boxChat.put(chat);
    }
  }

  Future<String> _createFileFromString() async {
    Uint8List bytes = base64.decode(photo!);
    String dir = (await getApplicationDocumentsDirectory()).path;
    File file = File(
        "$dir/" + DateTime.now().millisecondsSinceEpoch.toString() + ".png");
    await file.writeAsBytes(bytes);
    setState(() {
      image = File(file.path);
    });
    return file.path;
  }

  @override
  void initState()  {
    _tabController =  new TabController(initialIndex: 1,length: 4,vsync: this);
    super.initState();

    // getData();
    if(photo!=null){
      if(photo!=''){
        _createFileFromString();
      }
    }

    //masukin user data ke objectBox
    getDataUser();

    setupInteractedMessage();

    listController.addStream(mains.objectbox.queryStreamChat.map((q) => q.find()));
    listControllerConversation.addStream(mains.objectbox.queryStreamConversation.map((q) => q.find()));
    listControllerContact.addStream(mains.objectbox.queryStreamContact.map((q) => q.find()));

    if(mains.objectbox.boxUser.isEmpty()){}
    else{

      _doConnect();

      // channel = IOWebSocketChannel.connect(Uri.parse('wss://chat.dev.r17.co.id:443/wss/?open_key=2K0LJBnj7BK17sdlH65jhB33Ky1V2bY5Tcr09Ex8e76wZ54eRc4dF1H2G7vG570J9H8465GJ&email=${mains.objectbox.boxUser.get(1)?.email.toString()}'));
      //
      // channel.stream.listen((message) {
      //
      //   var objMessage = json.decode(message);
      //   print(objMessage.toString());
      //
      //   if(objMessage['type']=="pm"){
      //       var query = mains.objectbox.boxConversation.query(ConversationModel_.idReceiver.equals(objMessage['id_sender'])).build();
      //       if(query.find().isNotEmpty) {
      //         int? count = query
      //             .find()
      //             .first
      //             .messageCout;
      //         if (count == null)
      //           count = 1;
      //         else
      //           count = count + 1;
      //
      //         ConversationModel objConversation = ConversationModel(
      //             id: query.find().first.id,
      //             idReceiver: objMessage['id_sender'],
      //             fullName: query.find().first.fullName,
      //             image: query.find().first.image,
      //             message: objMessage['msg_data'],
      //             date: objMessage['msg_date'],
      //             messageCout: count);
      //             mains.objectbox.boxConversation.put(objConversation);
      //
      //
      //       }
      //       else{
      //         ConversationModel objConversation = ConversationModel(
      //             id: 0,
      //             idReceiver: objMessage['id_sender'],
      //             fullName: objMessage['name_sender'],
      //             image: '',
      //             message: objMessage['msg_data'],
      //             date: objMessage['msg_date'],
      //             messageCout: 1);
      //
      //             mains.objectbox.boxConversation.put(objConversation);
      //       }
      //
      //       final chat = ChatModel(
      //         idChatFriends: objMessage['id_chat_model'],
      //         idSender: objMessage['id_sender'],
      //         idReceiver: objMessage['id_receiver'],
      //         text: objMessage['msg_data'],
      //         date: objMessage['msg_date'],
      //         sendStatus: '',
      //         delivered: 0,
      //         read: 0,
      //       );
      //       int id = mains.objectbox.boxChat.put(chat);
      //     }
      //   else if(objMessage['type']=="status_deliver"){
      //      ChatModel cm = mains.objectbox.boxChat.get(objMessage['id_chat_model'])!;
      //       print(objMessage['send_status']);
      //      final chat = ChatModel(
      //        id: cm.id,
      //        idSender: cm.idSender,
      //        idReceiver: cm.idReceiver,
      //        text: cm.text,
      //        date: cm.date,
      //        sendStatus: objMessage['send_status'],
      //        delivered: 0,
      //        read: 0,
      //      );
      //      int id = mains.objectbox.boxChat.put(chat);
      //   }
      // });
    }

  }

  void connect() {
    _doConnect();
  }
  void _doConnect() {
    if (channel != null) {
      close();
    }
    channel = IOWebSocketChannel.connect(
      Uri.parse('wss://chat.dev.r17.co.id:443/wss/?open_key=2K0LJBnj7BK17sdlH65jhB33Ky1V2bY5Tcr09Ex8e76wZ54eRc4dF1H2G7vG570J9H8465GJ&email=${mains.objectbox.boxUser.get(1)?.email.toString()}'),
      pingInterval: Duration(
        seconds: 1,
      ),
    );
    channel.stream.listen(onReceiveData,
        onDone: onClosed, onError: onError, cancelOnError: false);
  }

  void onReceiveData(message) {

    var objMessage = json.decode(message);
    // print(objMessage);

    if(objMessage['type']=="pm"){
      //Update Conversation Model
      var query = mains.objectbox.boxConversation.query(ConversationModel_.idReceiver.equals(objMessage['id_sender'])).build();
      if(query.find().isNotEmpty) {
        int? count = query
            .find()
            .first
            .messageCout;
        if (count == null)
          count = 1;
        else
          count = count + 1;

        ConversationModel objConversation = ConversationModel(
            id: query.find().first.id,
            idReceiver: objMessage['id_sender'],
            fullName: query.find().first.fullName,
            image: query.find().first.image,
            photoProfile: query.find().first.photoProfile,
            message: objMessage['msg_data'],
            date: objMessage['msg_date'],
            messageCout: count,
            statusReceiver: query.find().first.statusReceiver,
            roomId: objMessage['room_id']);
        mains.objectbox.boxConversation.put(objConversation);
      }
      else{
        ConversationModel objConversation = ConversationModel(
            id: 0,
            idReceiver: objMessage['id_sender'],
            fullName: objMessage['name_sender'],
            image: '',
            photoProfile: objMessage['photo'],
            message: objMessage['msg_data'],
            date: objMessage['msg_date'],
            messageCout: 1,
            statusReceiver: '',
            roomId: objMessage['room_id']);
        mains.objectbox.boxConversation.put(objConversation);
      }

      //update Chat Model
      final chat = ChatModel(
        idChatFriends: objMessage['id_chat_model'],
        idSender: objMessage['id_sender'],
        idReceiver: objMessage['id_receiver'],
        text: objMessage['msg_data'],
        date: objMessage['msg_date'],
        sendStatus: '',
        delivered: 0,
        read: 0,
      );
      int id = mains.objectbox.boxChat.put(chat);
    }
    else if(objMessage['type']=="status_deliver"){
      ChatModel cm = mains.objectbox.boxChat.get(objMessage['id_chat_model'])!;
      print(objMessage['send_status']);
      final chat = ChatModel(
        id: cm.id,
        idSender: cm.idSender,
        idReceiver: cm.idReceiver,
        text: cm.text,
        date: cm.date,
        sendStatus: objMessage['send_status'],
        delivered: 0,
        read: 0,
      );
      int id = mains.objectbox.boxChat.put(chat);
    }
    else if(objMessage['type']=="status_typing"){
      //Update Typing Status
      //print(" \n\n" + json.encode(objMessage)   + "\n\n");
      var query = mains.objectbox.boxConversation.query(ConversationModel_.idReceiver.equals(objMessage['id_sender'])).build();
      if(query.find().isNotEmpty) {
        ConversationModel objConversation = ConversationModel(
            id: query.find().first.id,
            idReceiver: query.find().first.idReceiver,
            fullName: query.find().first.fullName,
            image: query.find().first.image,
            photoProfile: query.find().first.photoProfile,
            message: query.find().first.message,
            date: query.find().first.date,
            messageCout: query.find().first.messageCout,
            statusReceiver: objMessage['send_status'],
            roomId: query.find().first.roomId);
        mains.objectbox.boxConversation.put(objConversation);

        // Delete typing status after 2 seconds
        setState((){});
        Future.delayed(Duration(milliseconds: 2000)).whenComplete((){
          ConversationModel objConversation = ConversationModel(
              id: query.find().first.id,
              idReceiver: query.find().first.idReceiver,
              fullName: query.find().first.fullName,
              image: query.find().first.image,
              photoProfile: query.find().first.photoProfile,
              message: query.find().first.message,
              date: query.find().first.date,
              messageCout: query.find().first.messageCout,
              statusReceiver: '',
              roomId: query.find().first.roomId);
          mains.objectbox.boxConversation.put(objConversation);
          setState((){});
        });

      }
    }
    else if(objMessage['type']=="group"){
      // print(objMessage['id_receivers'].runtimeType);
      List<int> id_receivers = json.decode(objMessage['id_receivers']).cast<int>();
      // print(id_receivers);
      id_receivers.removeWhere((element) => element == mains.objectbox.boxUser.get(1)!.userId);
      id_receivers.add(objMessage['id_sender']);
      // print(json.encode(id_receivers));

      var query = mains.objectbox.boxConversation.query(ConversationModel_.roomId.equals(objMessage['room_id'])).build();
      if(query.find().isNotEmpty) {
        int? count = query
            .find()
            .first
            .messageCout;
        if (count == null)
          count = 1;
        else
          count = count + 1;

        ConversationModel objConversation = ConversationModel(
            id: query.find().first.id,
            idReceiversGroup: json.encode(id_receivers),
            fullName: query.find().first.fullName,
            image: query.find().first.image,
            photoProfile: objMessage['image'],
            message: objMessage['msg_data'],
            date: objMessage['msg_date'],
            messageCout: count,
            statusReceiver: query.find().first.statusReceiver,
            roomId: objMessage['room_id']);
        mains.objectbox.boxConversation.put(objConversation);
      }else{
        ConversationModel objConversation = ConversationModel(
          id: 0,
          idReceiversGroup: json.encode(id_receivers),
          fullName: objMessage['group_name'],
          image: '',
          photoProfile: objMessage['image'],
          message: objMessage['msg_data'],
          date: objMessage['msg_date'],
          messageCout: 1,
          statusReceiver: '',
          roomId: objMessage['room_id'],
        );
        mains.objectbox.boxConversation.put(objConversation);
      }

      //update Chat Model
      final chat = ChatModel(
        idChatFriends: objMessage['id_chat_model'],
        idSender: objMessage['id_sender'],
        nameSender: objMessage['name_sender'],
        idRoom: objMessage['room_id'],
        idReceiversGroup: objMessage['id_receivers'],
        text: objMessage['msg_data'],
        date: objMessage['msg_date'],
        sendStatus: '',
        delivered: 0,
        read: 0,
      );
      int id = mains.objectbox.boxChat.put(chat);

    }
  }
  void onClosed() {
    new Future.delayed(Duration(seconds: 1), () {
      _doConnect();
    });
  }

  void onError(err, StackTrace stackTrace) {
    print("websocket error:" + err.toString());
    if (stackTrace != null) {
      print(stackTrace);
    }
  }

  void close() {
    channel.sink.close();
  }

  @override
  void dispose() {
    _tabController!.dispose();
    super.dispose();
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  File? image;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          bottom: TabBar(
            controller: _tabController,
            indicatorColor: Colors.white,
            indicatorWeight: 4,
            labelStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            tabs: [
              Tab(
                text: 'News',
              ),
              Tab(
                text: 'Chat',
              ),
              Tab(
                text: 'Home',
              ),
              Tab(
                text: 'History',
              ),
            ],
          ),
          title: Text('eOffice',
            style: TextStyle(fontSize: 17),),
          actions: <Widget>[
            InkWell(
                onTap: (){
                  print(image);
                },
                child: Icon(Icons.search)),
            SizedBox(
              width: 10,
            ),
            InkWell(
                onTap: () =>_scaffoldKey.currentState?.openEndDrawer(),
                child: Icon(
                    Icons.more_vert
                )
            ),
            SizedBox(
              width: 10,
            ),
            // Theme(
            //   data: Theme.of(context).copyWith(
            //     dividerColor: Colors.white,
            //     iconTheme: IconThemeData(color: Colors.white),
            //     textTheme: TextTheme().apply(bodyColor: Colors.white),
            //   ),
            //   child: PopupMenuButton<int>(
            //     icon: Icon(Icons.more_vert),
            //     color: Colors.white,
            //     onSelected: (item) => onSelected(context, item),
            //     itemBuilder: (context) => [
            //       PopupMenuItem<int>(
            //         value: 0,
            //         child: Text('Profile'),
            //         textStyle: TextStyle(color: Colors.black,fontSize: 17),
            //       ),
            //       PopupMenuItem<int>(
            //         value: 1,
            //         child: Text('New Group'),
            //         textStyle: TextStyle(color: Colors.black,fontSize: 17),
            //       ),
            //       PopupMenuItem<int>(
            //         value: 2,
            //         child: Text('Settings'),
            //         textStyle: TextStyle(color: Colors.black,fontSize: 17),
            //       ),
            //       PopupMenuItem<int>(
            //         value: 3,
            //         child: Text('About'),
            //         textStyle: TextStyle(color: Colors.black,fontSize: 17),
            //       ),
            //     ],
            //   ),
            // ),
            SizedBox(
              width: 5,
            ),
          ],
        ),
        endDrawer: Drawer(
          child: ListView(
            padding: EdgeInsets.symmetric(vertical: 30, horizontal: 20),
            children: [
              SizedBox(height: 50,),
              // StreamBuilder<List<UserModel>>(
              //     stream: listControllerUser.stream,
              //     builder: (context, snapshot){
              //       List<UserModel> userList = mains.objectbox.boxUser.getAll().toList();
              //       return ListView.builder(
              //         itemCount: userList.length,
              //         itemBuilder:(BuildContext context,index)=>
              //             ListTile(
              //               title: Row(
              //                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //                 children: [
              //                   InkWell(
              //                     onTap: () {
              //                       Navigator.of(context).push(
              //                         MaterialPageRoute(builder: (context) => ProfilePage()),
              //                       );
              //                     },
              //                     child: Row(
              //                       children: [
              //                         image != null ? CircleAvatar(
              //                           radius: 20,
              //                           backgroundColor: Color(0xffF2F1F6),
              //                           backgroundImage: Image.file(
              //                               image!).image,
              //                         ) : CircleAvatar(
              //                           radius: 50,
              //                           backgroundColor: Color(0xffF2F1F6),
              //                           child: Icon(
              //                             Icons.person,
              //                             color: Colors.grey,
              //                           ),
              //                         ),
              //                         SizedBox(width: 15,),
              //                         Text(userList[index].userName!,
              //                           style: TextStyle(
              //                             fontSize: 16,
              //                             fontWeight: FontWeight.normal,
              //                           ),
              //                         ),
              //                       ],
              //                     ),
              //                   ),
              //                   InkWell(
              //                     onTap: () {
              //                       Navigator.of(context).push(
              //                         MaterialPageRoute(builder: (context) => SettingsPage()),
              //                       );
              //                     },
              //                     child: Icon(Icons.settings,
              //                       color: Colors.grey,
              //                     ),
              //                   )
              //                 ],
              //               ),
              //             ),
              //       );
              //     }
              // ),
              ListTile(
                title: Row(
                  children: [
                    Icon(
                      Icons.person_outline_rounded,
                      color: Theme.of(context).inputDecorationTheme.labelStyle?.color,
                      size: 20,
                    ),
                    SizedBox(width: 10,),
                    Text('Profile',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.normal,
                      ),),
                  ],
                ),
                onTap: () {
                  Navigator.push(context,
                    MaterialPageRoute(builder: (context) => ProfilePage()),
                  );
                },
              ),
              ListTile(
                title: Row(
                  children: [
                    Icon(
                      Icons.chat_bubble_outline,
                      color: Theme.of(context).inputDecorationTheme.labelStyle?.color,
                      size: 20,
                    ),
                    SizedBox(width: 10,),
                    Text('Chats',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.normal,
                      ),),
                  ],
                ),
                onTap: () {
                  Navigator.push(context,
                    MaterialPageRoute(builder: (context) => ChatSettingPage()),
                  );
                },
              ),
              ListTile(
                title: Row(
                  children: [
                    Icon(
                      Icons.notifications_none_rounded,
                      color: Theme.of(context).inputDecorationTheme.labelStyle?.color,
                      size: 20,
                    ),
                    SizedBox(width: 10,),
                    Text('Notification',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.normal,
                      ),),
                  ],
                ),
                onTap: () {
                  Navigator.push(context,
                    MaterialPageRoute(builder: (context) => NotificationPage()),
                  );
                },
              ),
              ListTile(
                title: Row(
                  children: [
                    Icon(
                      Icons.info_outline_rounded,
                      color: Theme.of(context).inputDecorationTheme.labelStyle?.color,
                      size: 20,
                    ),
                    SizedBox(width: 10,),
                    Text('Info',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.normal,
                      ),),
                  ],
                ),
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => AboutPage()),
                  );
                },
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            FeedTabScreen(),
            ChatTabScreen(),
            XploreTabScreen(),
            CallTabScreen(),
          ],
          controller: _tabController,
        ),
        floatingActionButton: FloatingActionButton(
          elevation: 0,
          child: Icon(Icons.add),
          onPressed: (){
            Navigator.push(context,
              MaterialPageRoute(builder: (context) => (ContactPage())),
            );
          },
        ),
      ),
    );
  }

  void onSelected(BuildContext context, int item)  {
    switch (item) {
      case 0:
        Navigator.of(context).push(
          MaterialPageRoute(builder: (context) => ProfilePage()),
        );
        break;
      case 1:
        Navigator.of(context).push(
          MaterialPageRoute(builder: (context) => NewGroupPage()),
        );
        break;
      case 2:
        Navigator.of(context).push(
          MaterialPageRoute(builder: (context) => SettingsPage()),
        );
        break;
      case 3:
        Navigator.of(context).push(
          MaterialPageRoute(builder: (context) => AboutPage()),
        );
        break;
    }
  }

  Future<http.Response> getDataUser() async {

    String url ='https://chat.dev.r17.co.id/get_user.php';

    Map<String, dynamic> data = {
      'api_key': this.apiKey,
      'email': mains.objectbox.boxUser.get(1)?.email,
    };

    //encode Map to JSON
    //var body = "?api_key="+this.apiKey;

    var response = await http.post(Uri.parse(url),
      headers: {"Content-Type": "application/json"},
      body:jsonEncode(data),
    );
    if(response.statusCode == 200){
      //print("${response.body}");
      Map<String, dynamic> userMap = jsonDecode(response.body);

      if(userMap['code_status'] == 0){

        var user = UserModel(
          id: 1,
          email: email,
          userId: userMap['id'],
          userName: userMap['name'],
          phone: userMap['phone'],
          photo: userMap['photo'],
        );

        mains.objectbox.boxUser.put(user);

        // setState(() {
        //   userId = userMap['id'];
        //   name = userMap['name'];
        //   phone = userMap['phone'];
        //   photo = userMap['photo'];
        // });

      }else{
        print("ada yang salah!");
      }
    }
    else{
      print("Gagal terhubung ke server!");
    }
    return response;
  }

  Future<http.Response> setPhoto(String photo64) async {

    String url ='https://chat.dev.r17.co.id/profile.php';


    Map<String, dynamic> data = {
      'api_key': this.apiKey,
      'email': email,
      'photo64': photo64,
    };

    //encode Map to JSON
    //var body = "?api_key="+this.apiKey;

    var response = await http.post(Uri.parse(url),
      headers: {"Content-Type": "application/json"},
      body:jsonEncode(data),
    );
    if(response.statusCode == 200){
      //print("${response.body}");
      Map<String, dynamic> userMap = jsonDecode(response.body);

      if(userMap['code_status'] == 0){

        print(userMap['photo64']);

      }else{
        print(userMap['code_status']);
        print("ada yang salah!");
      }
    }
    else{
      print("Gagal terhubung ke server!");
      print(response.statusCode);
    }
    return response;
  }

}
