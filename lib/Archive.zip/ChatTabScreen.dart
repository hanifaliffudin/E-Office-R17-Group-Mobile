import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:badges/badges.dart';
import 'package:militarymessenger/ChatGroup.dart';
import 'package:militarymessenger/ChatScreen.dart';
import 'package:militarymessenger/contact.dart';
import 'package:militarymessenger/models/ConversationModel.dart';
import 'objectbox.g.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:intl/intl.dart';
import 'ChatScreen.dart';
import 'models/ConversationModel.dart';

import 'Home.dart' as homes;
import 'main.dart' as mains;


class ChatTabScreen extends StatefulWidget {

  ChatTabScreen();

  @override
  State<ChatTabScreen> createState() => _ChatTabScreenState();
}

class _ChatTabScreenState extends State<ChatTabScreen> {
  Store? store;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ConversationModel>>(
        stream: homes.listControllerConversation.stream,
        builder: (context, snapshot){
          if(mains.objectbox.boxConversation.isEmpty()){
            return
              Container(
                  margin: const EdgeInsets.only(top: 15.0),
                  child :Text(
                    'No chats yet.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontWeight: FontWeight.normal, fontSize: 13,),
                  ));
          }
          else
          {
            var builder = mains.objectbox.boxConversation.query(ConversationModel_.id > 0)
              ..order(ConversationModel_.date, flags: Order.descending);
            List<ConversationModel> conversationList = builder.build().find().toList();

            //List<ConversationModel> conversationList = mains.objectbox.boxConversation.getAll().reversed.toList();

            return Container(
              padding: EdgeInsets.all(10),
              child: ListView.builder(
                  itemCount: conversationList.length,
                  itemBuilder:(BuildContext context,index)=>conversation(context,conversationList[index])
              ),
            );
          }
        }
    );
  }
}

Widget conversation(BuildContext context, ConversationModel conversation) {

  DateTime dateTime = DateTime.parse(conversation.date!);
  String formattedDate = DateFormat('HH:mm').format(dateTime);

  //print("\n\n Room id ${conversation.roomId}"  );
  //print("\n\n Room id ${conversation.fullName}");

  return InkWell(
      onTap: (){
        if(conversation.idReceiver != null){
          Navigator.of(context).push(
              MaterialPageRoute(builder: (BuildContext context)=>ChatScreen(conversation, conversation.roomId!))
          );
        }else{
          Navigator.of(context).push(
              MaterialPageRoute(builder: (BuildContext context)=>ChatGroup(conversation, conversation.roomId!))
          );
        }

      },
      child: Card(
        child: Container(
          padding: EdgeInsets.all(5),
          child: Column(
            children: <Widget>[
              ListTile(
                leading: ClipOval(
                    child:  conversation.idReceiver != null && conversation.photoProfile==''
                        ?
                    CircleAvatar(
                      radius: 20,
                      backgroundColor: Color(0xffdde1ea),
                      child:  Icon(
                        Icons.person,
                        color: Colors.grey,
                      ),
                    )
                        : conversation.idReceiversGroup != null && conversation.photoProfile==null  ?
                    CircleAvatar(
                      radius: 20,
                      backgroundColor: Color(0xffdde1ea),
                      child:  Icon(
                        Icons.people_rounded,
                        color: Colors.grey,
                      ),
                    )
                        : conversation.photoProfile=="" ?
                    CircleAvatar(
                      radius: 20,
                      backgroundColor: Color(0xffdde1ea),
                      child:  Icon(
                        Icons.people_rounded,
                        color: Colors.grey,
                      ),
                    )
                        :
                    CircleAvatar(
                      backgroundImage: Image.memory(base64.decode(conversation.photoProfile!)).image,
                      backgroundColor: Colors.white,
                      radius: 25,
                    )
                ),
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[

                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        ConstrainedBox(
                          constraints: BoxConstraints(
                              maxWidth: 220
                          ),
                          child: Text(
                            conversation.fullName!,
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                          ),
                        ),
                        conversation.message != null ?
                        ConstrainedBox(
                          constraints: BoxConstraints(
                              maxWidth: 220
                          ),
                          child: conversation.statusReceiver=='' ?
                          Text(
                            conversation.message!,
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                            style: TextStyle(color: Colors.grey, fontSize: 14, height: 1.5),
                          ):Text(
                            conversation.statusReceiver,
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                            style: TextStyle(color: Color(0xFF25D366), fontSize: 14),
                          )
                          ,
                        ) :
                        Text(
                          "",
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                          style: TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                    Column(
                      // crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text(
                          formattedDate,
                          style: TextStyle(
                              color: conversation.messageCout! > 0
                                  ? Color(0xFF25D366)
                                  : Colors.grey,
                              fontSize: 11),
                        ),
                        conversation.messageCout! > 0
                            ?
                        Transform(
                            transform: new Matrix4.identity()..scale(0.8),
                            child: Chip(
                              backgroundColor: Color(0xFF25D366),
                              label: Text(
                                '${conversation.messageCout}',
                                style: TextStyle(color: Colors.white , fontSize: 12),
                              ),
                            )
                        )
                            :
                        Transform(
                            transform: new Matrix4.identity()..scale(0.8),
                            child: Chip(
                              backgroundColor: Theme.of(context).floatingActionButtonTheme.foregroundColor,
                              label: Text(
                                '',
                                style: TextStyle(color: Colors.white, fontSize: 12),
                              ),
                            )
                        )
                      ],
                    )

                  ],
                ),
              ),
            ],
          ),
        ),
      )
  );
}
