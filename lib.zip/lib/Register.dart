import 'package:flutter/material.dart';

class Register extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text('Login R17 Messenger'),
      centerTitle: true,
      backgroundColor: Color(0xFF2381d0),
    ),
  );
}